module PatchKitTools
  VERSION = '3.1.3'.freeze
end
